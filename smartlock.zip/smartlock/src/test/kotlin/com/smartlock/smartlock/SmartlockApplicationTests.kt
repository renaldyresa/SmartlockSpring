package com.smartlock.smartlock

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SmartlockApplicationTests {

	@Test
	fun contextLoads() {
	}

}
