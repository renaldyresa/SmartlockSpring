package com.smartlock.smartlock.model

data class AuthenticationResponse(
        var jwt: String
)
