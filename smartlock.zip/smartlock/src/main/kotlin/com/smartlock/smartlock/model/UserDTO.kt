package com.smartlock.smartlock.model


data class UserDTO(
        var username: String,
        var password: String
)