rootProject.name = "smartlock"
